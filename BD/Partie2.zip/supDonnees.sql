delete from Reservation where 1;
delete from Operateur where 1;
delete from Animal where 1;
delete from Administrateur where 1;
delete from Client where 1;