drop table Operateur, Reservation, Animal, Administrateur;
drop table Client;
